bl_info = {
    "name":        "Renderfarm Render Submitter",
    "author":      "Renderfarm",
    "version":     (1, 0, 0),
    "blender":     (3, 0, 0),
    "location":    "Properties > Render > Renderfarm Render Submitter",
    "description": "Submit render jobs to Renderfarm directly from Blender",
    "category":    "Render",
}

import bpy
import json
import urllib.request
import urllib.error
import urllib.parse
import http.server
import threading
import webbrowser
import os
import sys
from bpy.types import Operator, Panel, PropertyGroup
from bpy.props import StringProperty, CollectionProperty
from bpy.utils import register_class, unregister_class

# ──────────────────────────────────────────────────────────────────────────────
# Config
# ──────────────────────────────────────────────────────────────────────────────
API_BASE      = "https://renderfarm-web.vercel.app/api"
WEB_BASE      = "https://renderfarm-web.vercel.app"
CALLBACK_PORT = 8989
_TOKEN_FILE   = os.path.join(os.path.dirname(__file__), ".rf_token")

# ──────────────────────────────────────────────────────────────────────────────
# Token persistence
# ──────────────────────────────────────────────────────────────────────────────
def _save_token(token, email):
    with open(_TOKEN_FILE, "w") as f:
        json.dump({"token": token, "email": email}, f)

def _load_token():
    if not os.path.exists(_TOKEN_FILE):
        return None, None
    try:
        with open(_TOKEN_FILE) as f:
            d = json.load(f)
            return d.get("token"), d.get("email")
    except Exception:
        return None, None

def _clear_token():
    if os.path.exists(_TOKEN_FILE):
        os.remove(_TOKEN_FILE)

# ──────────────────────────────────────────────────────────────────────────────
# HTTP helpers
# ──────────────────────────────────────────────────────────────────────────────
def _get(path, token):
    req = urllib.request.Request(
        f"{API_BASE}{path}",
        headers={"Authorization": f"Bearer {token}"},
        method="GET",
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read())

def _post(path, payload, token=None):
    data = json.dumps(payload).encode()
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(
        f"{API_BASE}{path}", data=data, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read())

# ──────────────────────────────────────────────────────────────────────────────
# Browser-auth local callback server
# ──────────────────────────────────────────────────────────────────────────────
_auth_server        = None
_auth_server_thread = None

class _CallbackHandler(http.server.BaseHTTPRequestHandler):
    """Receives the token redirect from the Renderfarm web page."""

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)

        token = params.get("token", [None])[0]
        email = params.get("email", [None])[0]

        if parsed.path == "/callback" and token and email:
            # Send a friendly HTML response the browser shows
            html = b"""<!DOCTYPE html><html><head>
            <meta charset="utf-8">
            <title>Renderfarm - Connected</title>
            <style>
              body{margin:0;min-height:100vh;display:flex;align-items:center;
                   justify-content:center;background:#0d0d1a;
                   font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#fff}
              .card{background:#1a1a2e;border:1px solid #2a2a4a;border-radius:16px;
                    padding:48px;text-align:center;max-width:380px}
              .icon{font-size:56px;color:#22d3ee;display:block;margin-bottom:16px}
              h1{margin:0 0 8px;font-size:22px}
              p{color:#8888aa;margin:0;font-size:14px}
            </style></head><body>
            <div class="card">
              <span class="icon">&#9889;</span>
              <h1>Blender Connected!</h1>
              <p>You can close this tab and return to Blender.</p>
            </div></body></html>"""

            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(html)

            # Apply token back on the main thread
            def _apply():
                _on_auth_success(token, email)
                _stop_auth_server()

            bpy.app.timers.register(_apply, first_interval=0.1)

        else:
            self.send_response(400)
            self.end_headers()

    def log_message(self, fmt, *args):
        pass  # suppress terminal spam


def _start_auth_server():
    global _auth_server, _auth_server_thread
    if _auth_server:
        return
    try:
        _auth_server = http.server.HTTPServer(("127.0.0.1", CALLBACK_PORT), _CallbackHandler)
        _auth_server_thread = threading.Thread(target=_auth_server.serve_forever, daemon=True)
        _auth_server_thread.start()
    except OSError:
        # Port already in use — previous server still running, that's fine
        pass


def _stop_auth_server():
    global _auth_server, _auth_server_thread
    if _auth_server:
        threading.Thread(target=_auth_server.shutdown, daemon=True).start()
        _auth_server        = None
        _auth_server_thread = None


def _on_auth_success(token, email):
    """Called on the main thread after the browser callback delivers the token."""
    try:
        prefs = bpy.context.preferences.addons[__name__].preferences
        prefs.access_token = token
        prefs.user_email   = email
    except Exception:
        pass

    _save_token(token, email)

    # Fetch data and populate menus
    try:
        scene    = bpy.context.scene
        projects = _get("/projects", token)
        _populate_project_menu(projects)
        _populate_machine_menu(scene.rf_instance_type)
        _populate_camera_menu(bpy.context)
        _set_resolution(bpy.context)
        scene.rf_job_title   = _get_job_title()
        scene.rf_frame_range = _get_scene_frame_range()
        if not scene.rf_output_folder:
            scene.rf_output_folder = _get_output_folder()
        _populate_frame_info()
        scene.rf_status_msg  = f"Connected as {email}"
        scene.rf_status_type = "OK"
        _refresh_ui()
        _refresh_properties()
    except Exception as e:
        try:
            bpy.context.scene.rf_status_msg  = f"Connected but sync failed: {e}"
            bpy.context.scene.rf_status_type = "ERROR"
        except Exception:
            pass

# ──────────────────────────────────────────────────────────────────────────────
# UI helpers
# ──────────────────────────────────────────────────────────────────────────────
def _refresh_ui():
    bpy.ops.wm.redraw_timer(type="DRAW_WIN_SWAP", iterations=1)

def _refresh_properties():
    for area in bpy.context.screen.areas:
        if area.type == "PROPERTIES":
            area.tag_redraw()

def _get_scene_frame_range():
    s = bpy.context.scene
    return f"{s.frame_start}-{s.frame_end}"

def _get_token():
    try:
        return bpy.context.preferences.addons[__name__].preferences.access_token or None
    except Exception:
        return None

def _get_email():
    try:
        return bpy.context.preferences.addons[__name__].preferences.user_email or ""
    except Exception:
        return ""

# ──────────────────────────────────────────────────────────────────────────────
# Software / instance data
# ──────────────────────────────────────────────────────────────────────────────
BLENDER_VERSIONS = [
    ("blender-4-2-lts", "Blender 4.2 LTS", ""),
    ("blender-4-1",     "Blender 4.1",     ""),
    ("blender-4-0",     "Blender 4.0",     ""),
    ("blender-3-6-lts", "Blender 3.6 LTS", ""),
    ("blender-3-5",     "Blender 3.5",     ""),
    ("blender-3-4",     "Blender 3.4",     ""),
    ("blender-3-3-lts", "Blender 3.3 LTS", ""),
]

INSTANCE_TYPES = {
    "GPU": [
        ("a100-80gb-1", "A100 80GB · 12 vCPU · 85 GB",  ""),
        ("a100-40gb-1", "A100 40GB · 12 vCPU · 85 GB",  ""),
        ("l4-1",        "L4 24GB · 8 vCPU · 32 GB",     ""),
        ("t4-1",        "T4 16GB · 4 vCPU · 15 GB",     ""),
        ("v100-1",      "V100 16GB · 8 vCPU · 52 GB",   ""),
    ],
    "CPU": [
        ("n1-highcpu-64", "n1-highcpu-64 · 64 vCPU · 57.6 GB", ""),
        ("n1-highcpu-32", "n1-highcpu-32 · 32 vCPU · 28.8 GB", ""),
        ("n1-highcpu-16", "n1-highcpu-16 · 16 vCPU · 14.4 GB", ""),
        ("n1-highcpu-8",  "n1-highcpu-8 · 8 vCPU · 7.2 GB",   ""),
    ],
}

# ──────────────────────────────────────────────────────────────────────────────
# Populate helpers
# ──────────────────────────────────────────────────────────────────────────────
def _populate_project_menu(projects):
    items = [(p["id"], p["name"], "") for p in projects if p.get("isActive", True)]
    if not items:
        items = [("none", "No Projects", "")]
    bpy.types.Scene.rf_project = bpy.props.EnumProperty(
        name="Project",
        description="Renderfarm project to run the job in.",
        items=items,
    )

def _populate_machine_menu(instance_type="GPU"):
    items = INSTANCE_TYPES.get(instance_type, INSTANCE_TYPES["GPU"])
    bpy.types.Scene.rf_machine_type = bpy.props.EnumProperty(
        name="Machine Type",
        description="Select the machine for your render.",
        items=items,
    )

def _update_instance_type(self, context):
    _populate_machine_menu(context.scene.rf_instance_type)
    _refresh_ui()

def _populate_camera_menu(context):
    scene = context.scene
    items = [(c.name, c.name, "") for c in scene.objects if c.type == "CAMERA"]
    if not items:
        items = [("none", "No Cameras", "")]
    def _update_cam(self, context):
        obj = context.scene.objects.get(self.rf_camera_override)
        if obj:
            context.scene.camera = obj
    bpy.types.Scene.rf_camera_override = bpy.props.EnumProperty(
        name="Camera", items=items, update=_update_cam)
    if scene.camera:
        try:
            scene.rf_camera_override = scene.camera.name
        except Exception:
            pass

def _populate_frame_info():
    scene = bpy.context.scene
    try:
        frame_range = scene.rf_frame_range if scene.rf_use_custom_range else _get_scene_frame_range()
        chunk       = max(1, scene.rf_chunk_size)
        parts       = frame_range.replace(" ", "").split("-")
        start       = int(parts[0])
        end         = int(parts[-1]) if len(parts) > 1 else start
        count       = max(0, end - start + 1)
        tasks       = max(1, (count + chunk - 1) // chunk)
        scene.rf_frame_spec  = frame_range
        scene.rf_frame_count = str(count)
        scene.rf_task_count  = str(tasks)
    except Exception:
        pass

def _on_chunk_updated(self, context):  _populate_frame_info()
def _on_range_updated(self, context):  _populate_frame_info()

def _set_resolution(context):
    scene = context.scene
    render = scene.render
    try:
        if scene.rf_resolution_x   <= 0: scene.rf_resolution_x   = render.resolution_x
        if scene.rf_resolution_y   <= 0: scene.rf_resolution_y   = render.resolution_y
        if scene.rf_resolution_pct <= 0: scene.rf_resolution_pct = render.resolution_percentage
        if scene.rf_samples <= 0 and scene.render.engine == "CYCLES":
            scene.rf_samples = scene.cycles.samples
    except Exception:
        pass

def _get_output_folder():
    try:
        fp     = bpy.context.blend_data.filepath
        folder = os.path.dirname(fp) if fp else os.path.expanduser("~")
        out    = os.path.join(folder, "render")
        os.makedirs(out, exist_ok=True)
        return out
    except Exception:
        return ""

def _get_job_title():
    try:
        fp   = bpy.context.blend_data.filepath
        name = os.path.splitext(os.path.basename(fp))[0] if fp else "Untitled"
        v    = bpy.app.version
        return f"Blender {v[0]}.{v[1]}.{v[2]} Linux Render {name}"
    except Exception:
        return "Blender Linux Render"

# ──────────────────────────────────────────────────────────────────────────────
# Payload
# ──────────────────────────────────────────────────────────────────────────────
def _build_payload(context):
    scene       = context.scene
    frame_range = scene.rf_frame_range if scene.rf_use_custom_range else _get_scene_frame_range()
    env         = {v.variable_name: v.variable_value
                   for v in scene.rf_env_vars.variables if v.variable_name}
    return {
        "title":               scene.rf_job_title,
        "project":             scene.get("rf_project", ""),
        "instance_type":       scene.rf_instance_type,
        "machine_type":        scene.get("rf_machine_type", ""),
        "preemptible":         scene.rf_preemptible,
        "preemptible_retries": scene.rf_preemptible_retries,
        "software":            scene.rf_blender_version,
        "render_software":     scene.rf_render_software,
        "frames":              frame_range,
        "chunk_size":          scene.rf_chunk_size,
        "use_scout_frames":    scene.rf_use_scout_frames,
        "scout_frames":        scene.rf_scout_frames,
        "resolution_x":        scene.rf_resolution_x,
        "resolution_y":        scene.rf_resolution_y,
        "resolution_pct":      scene.rf_resolution_pct,
        "camera":              scene.get("rf_camera_override", ""),
        "samples":             scene.rf_samples,
        "output_folder":       scene.rf_output_folder,
        "disable_audio":       scene.rf_disable_audio,
        "extra_env":           env,
        "blender_file":        bpy.context.blend_data.filepath,
    }

# ──────────────────────────────────────────────────────────────────────────────
# Preferences  (no email/password — auth happens in the browser)
# ──────────────────────────────────────────────────────────────────────────────
class RFPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    access_token: StringProperty(default="")
    user_email:   StringProperty(default="")

    def draw(self, context):
        layout = self.layout
        if self.user_email:
            row = layout.row()
            row.label(text=f"Signed in as: {self.user_email}", icon="CHECKMARK")
            row.operator("rf.disconnect", text="Disconnect", icon="PANEL_CLOSE")
        else:
            layout.label(text="Click Connect in the Render Properties panel to sign in.", icon="INFO")

# ──────────────────────────────────────────────────────────────────────────────
# Property groups
# ──────────────────────────────────────────────────────────────────────────────
class RFExtraFileAsset(PropertyGroup):
    file_path: StringProperty(name="File Path", subtype="FILE_PATH")

class RFExtraDirAsset(PropertyGroup):
    dir_path: StringProperty(name="Dir Path", subtype="DIR_PATH")

class RFEnvVar(PropertyGroup):
    variable_name:  StringProperty(name="Variable")
    variable_value: StringProperty(name="Value")

class RFEnvVarList(PropertyGroup):
    variables: CollectionProperty(type=RFEnvVar)

class RFAddonProp(PropertyGroup):
    enabled:       bpy.props.BoolProperty(name="Enabled", default=False)
    name:          StringProperty(name="Name")
    version_items: StringProperty()

    def _get_versions(self, context):
        versions = self.version_items.split(",") if self.version_items else []
        return [(v, v, "") for v in versions] or [("none", "None", "")]

    menu_option: bpy.props.EnumProperty(name="Version", items=_get_versions)

# ──────────────────────────────────────────────────────────────────────────────
# Operators
# ──────────────────────────────────────────────────────────────────────────────
class RF_OT_Connect(Operator):
    bl_idname     = "rf.connect"
    bl_label      = "Connect"
    bl_description = "Open your browser to sign in to Renderfarm. Once signed in, Blender will be authorised automatically."

    def execute(self, context):
        scene = context.scene
        scene.rf_status_msg  = "Waiting for browser sign-in…"
        scene.rf_status_type = "INFO"
        _start_auth_server()
        url = f"{WEB_BASE}/login?port={CALLBACK_PORT}"
        webbrowser.open(url)
        self.report({"INFO"}, "Browser opened — sign in to connect Blender.")
        return {"FINISHED"}


class RF_OT_Disconnect(Operator):
    bl_idname     = "rf.disconnect"
    bl_label      = "Disconnect"
    bl_description = "Sign out and disconnect Blender from Renderfarm."

    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences
        prefs.access_token = ""
        prefs.user_email   = ""
        _clear_token()
        _stop_auth_server()
        context.scene.rf_status_msg  = ""
        context.scene.rf_status_type = "INFO"
        return {"FINISHED"}


class RF_OT_PreviewScript(Operator):
    bl_idname     = "rf.preview_script"
    bl_label      = "Preview Script"
    bl_description = "Export the job payload as JSON and open it."

    def execute(self, context):
        payload   = _build_payload(context)
        json_data = json.dumps(payload, indent=4)
        try:
            fp   = bpy.context.blend_data.filepath
            name = os.path.splitext(os.path.basename(fp))[0] if fp else "renderfarm_job"
            out  = os.path.join(os.path.dirname(fp) if fp else os.path.expanduser("~"), f"{name}.json")
            with open(out, "w") as f:
                f.write(json_data)
            if sys.platform.startswith("win"):
                os.startfile(out)
            elif sys.platform == "darwin":
                import subprocess; subprocess.call(["open", out])
            else:
                import subprocess; subprocess.call(["xdg-open", out])
        except Exception as e:
            self.report({"WARNING"}, f"Could not open file: {e}")
        return {"FINISHED"}


# ──────────────────────────────────────────────────────────────────────────────
# Submission dialog state  (shared between main thread and upload thread)
# ──────────────────────────────────────────────────────────────────────────────
_sub = {
    "tab":            "VALIDATION",   # VALIDATION | PROGRESS | RESPONSE
    "is_dirty":       False,
    "validation":     [],             # list of (icon, message)
    "prog_jobs":      0.0,            # 0.0 – 1.0
    "prog_md5":       0.0,
    "prog_upload":    0.0,
    "files":          [],             # list of [path, progress 0-1]
    "job_number":     "",
    "job_title":      "",
    "error":          "",
}

def _redraw():
    """Force Blender to repaint all regions (called from timer on main thread)."""
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            area.tag_redraw()

def _set_prog(key, value):
    _sub[key] = max(0.0, min(1.0, value))
    bpy.app.timers.register(_redraw, first_interval=0.05)


def _zip_scene(blend_path):
    """Zip the .blend file (+ linked assets one level deep) into a temp archive."""
    import tempfile, zipfile as zf
    tmp = tempfile.mktemp(suffix=".zip")
    blend_dir = os.path.dirname(blend_path)
    with zf.ZipFile(tmp, "w", zf.ZIP_DEFLATED) as z:
        z.write(blend_path, arcname=os.path.basename(blend_path))
        # Pack textures / linked files that sit next to the .blend
        for root, _, files in os.walk(blend_dir):
            for f in files:
                if f.endswith((".png", ".jpg", ".jpeg", ".exr", ".hdr",
                               ".tiff", ".tif", ".bmp", ".obj", ".fbx", ".abc")):
                    full = os.path.join(root, f)
                    rel  = os.path.relpath(full, blend_dir)
                    z.write(full, arcname=rel)
    return tmp


def _upload_scene(zip_path, token):
    """
    Upload zip to our /api/upload route, which proxies it into Vercel Blob.
    This avoids the client-token limitation for private blob stores.
    Returns the public blob URL.
    """
    filename = os.path.basename(zip_path)
    enc_name = urllib.parse.quote(filename)

    with open(zip_path, "rb") as f:
        data = f.read()

    url = f"{API_BASE}/upload?filename={enc_name}"
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type":  "application/zip",
        },
        method="PUT",
    )
    with urllib.request.urlopen(req, timeout=600) as r:
        result = json.loads(r.read())

    return result["url"]


# ──────────────────────────────────────────────────────────────────────────────
# Upload thread  (runs in background; updates _sub + redraws)
# ──────────────────────────────────────────────────────────────────────────────

def _start_upload_thread(context):
    """Kick off the background upload.  Must be called from the main thread."""
    _sub["tab"]         = "PROGRESS"
    _sub["prog_jobs"]   = 0.0
    _sub["prog_md5"]    = 0.0
    _sub["prog_upload"] = 0.0
    _sub["files"]       = []
    _sub["error"]       = ""
    _redraw()

    # Capture everything from context NOW – thread must not read bpy.context
    token      = _get_token()
    blend_path = bpy.context.blend_data.filepath
    payload    = _build_payload(context)
    scene      = context.scene

    def _run():
        try:
            import hashlib

            # ── 1  Jobs record placeholder (instant) ──────────────────────
            _set_prog("prog_jobs", 0.2)

            # ── 2  MD5 of .blend ──────────────────────────────────────────
            h = hashlib.md5()
            with open(blend_path, "rb") as fh:
                for chunk_data in iter(lambda: fh.read(65536), b""):
                    h.update(chunk_data)
            _set_prog("prog_md5", 1.0)
            _set_prog("prog_jobs", 0.5)

            # ── 3  Zip scene ───────────────────────────────────────────────
            zip_path = _zip_scene(blend_path)
            zip_name = os.path.basename(zip_path)

            def _show_file():
                _sub["files"] = [[zip_name, 0.0]]
                _redraw()
            bpy.app.timers.register(_show_file, first_interval=0)

            _set_prog("prog_jobs", 1.0)

            # ── 4  Upload to Vercel Blob ───────────────────────────────────
            _set_prog("prog_upload", 0.05)
            scene_url = _upload_scene(zip_path, token)
            os.unlink(zip_path)

            def _mark_uploaded():
                if _sub["files"]:
                    _sub["files"][0][1] = 1.0
                _redraw()
            bpy.app.timers.register(_mark_uploaded, first_interval=0)
            _set_prog("prog_upload", 1.0)

            # ── 5  Submit job record ───────────────────────────────────────
            payload["blender_file"] = scene_url
            result     = _post("/jobs", payload, token)
            job_number = result.get("jobNumber", result.get("id", "?"))

            def _done():
                _sub["tab"]          = "RESPONSE"
                _sub["job_number"]   = str(job_number)
                _sub["job_title"]    = payload.get("title", "Render Job")
                scene.rf_status_msg  = f"✓ Job {job_number} submitted"
                scene.rf_status_type = "OK"
                _redraw()
                _refresh_properties()
            bpy.app.timers.register(_done, first_interval=0)

        except urllib.error.HTTPError as e:
            body = e.read().decode(errors="replace")
            err  = f"HTTP {e.code} {e.reason}: {body[:150]}"
            def _err():
                _sub["tab"]          = "RESPONSE"
                _sub["error"]        = err
                scene.rf_status_msg  = f"Submit failed: {err}"
                scene.rf_status_type = "ERROR"
                _redraw()
            bpy.app.timers.register(_err, first_interval=0)

        except Exception as e:
            err = str(e)
            def _err():
                _sub["tab"]          = "RESPONSE"
                _sub["error"]        = err[:250]
                scene.rf_status_msg  = f"Error: {err}"
                scene.rf_status_type = "ERROR"
                _redraw()
            bpy.app.timers.register(_err, first_interval=0)

    threading.Thread(target=_run, daemon=True).start()


# ──────────────────────────────────────────────────────────────────────────────
# Dialog draw helpers
# ──────────────────────────────────────────────────────────────────────────────

def _draw_progress_bar(layout, factor, label, pct_done=None):
    """Conductor-style labeled progress bar."""
    factor = max(0.0, min(1.0, factor))
    pct    = pct_done if pct_done is not None else int(factor * 100)

    col = layout.column(align=True)
    row = col.row()
    row.scale_y = 0.8
    row.label(text=label)
    row2 = col.row(align=True)
    row2.scale_y = 1.4
    if bpy.app.version >= (3, 3, 0) and hasattr(row2, "progress"):
        row2.progress(factor=factor, text=f"{pct} %")
    else:
        done = int(factor * 10)
        row2.label(text="█" * done + "░" * (10 - done) + f"  {pct} %")


# ── Validation tab ─────────────────────────────────────────────────────────────
def _draw_validation(layout):
    has_errors = any(t == "ERROR" for t, _ in _sub["validation"])

    # ── header ─────────────────────────────────────────────
    header = layout.row()
    header.scale_y = 1.2
    header.label(text="Submit Render Job", icon="RENDER_STILL")
    layout.separator(factor=1.0)

    # ── validation messages ────────────────────────────────
    if not _sub["validation"]:
        ok_row = layout.row()
        ok_row.scale_y = 1.3
        ok_row.label(text="  Scene is ready to submit.", icon="CHECKMARK")
    else:
        for vtype, msg in _sub["validation"]:
            box = layout.box()
            box.alert = (vtype == "ERROR")
            inner = box.column(align=True)
            inner.scale_y = 1.1
            icon = "ERROR" if vtype == "ERROR" else "ERROR"
            inner.label(text=msg, icon=icon)
        if not has_errors:
            hint = layout.row()
            hint.scale_y = 0.9
            hint.label(
                text="  These issues are warnings only and can be skipped.",
                icon="INFO")

    layout.separator(factor=1.2)

    # ── action buttons ─────────────────────────────────────
    row = layout.row(align=True)
    row.scale_y = 1.5

    close = row.row()
    close.scale_x = 0.35
    close.operator("rf.submit_close", text="Close", icon="X")

    if not has_errors:
        if _sub["is_dirty"]:
            save_row = row.row()
            save_row.scale_x = 1.3
            save_row.operator("rf.save_and_continue",
                              text="Save Scene and Continue Submission",
                              icon="FILE_TICK")
        row.operator("rf.continue_submit",
                     text="Continue Submission", icon="PLAY")

    layout.separator(factor=0.5)


# ── Progress tab ───────────────────────────────────────────────────────────────
def _draw_progress(layout):
    header = layout.row()
    header.scale_y = 1.2
    header.label(text="Submitting Job…", icon="RENDER_ANIMATION")
    layout.separator(factor=1.0)

    _draw_progress_bar(layout, _sub["prog_jobs"],   "Jobs Progress")
    layout.separator(factor=0.8)
    _draw_progress_bar(layout, _sub["prog_md5"],    "Computing MD5")
    layout.separator(factor=0.8)
    _draw_progress_bar(layout, _sub["prog_upload"], "File Upload")

    # ── per-file list ──────────────────────────────────────
    if _sub["files"]:
        layout.separator(factor=1.0)
        box = layout.box()
        box.scale_y = 1.1
        for fname, fprog in _sub["files"]:
            row = box.row()
            row.label(text=fname, icon="FILE_ARCHIVE")
            badge = layout.row()           # spacer trick — keep inline
            done_pct = int(fprog * 100)
            status_col = row.row()
            status_col.alignment = "RIGHT"
            status_col.alert = (done_pct < 100)
            status_col.label(
                text=f"{done_pct} %",
                icon="CHECKMARK" if done_pct == 100 else "TIME")

    layout.separator(factor=0.5)


# ── Response tab ───────────────────────────────────────────────────────────────
def _draw_response(layout):
    if _sub["error"]:
        header = layout.row()
        header.scale_y = 1.2
        header.alert = True
        header.label(text="Submission Failed", icon="ERROR")
        layout.separator(factor=0.8)

        box = layout.box()
        box.alert = True
        for line in _sub["error"][:300].split("\n")[:6]:
            box.label(text=line or " ")

        layout.separator(factor=0.5)
        return

    # ── success ────────────────────────────────────────────
    header = layout.row()
    header.scale_y = 1.2
    header.label(text="Job Submitted!", icon="CHECKMARK")
    layout.separator(factor=1.0)

    box = layout.box()
    col = box.column(align=True)
    col.scale_y = 1.2
    col.label(text=_sub["job_title"], icon="RENDER_STILL")
    if _sub["job_number"]:
        col.label(text=f"Job number:  {_sub['job_number']}",
                  icon="SMALL_TRI_RIGHT_VEC")

    layout.separator(factor=1.2)

    dash = layout.row()
    dash.scale_y = 1.8
    dash.operator("rf.open_dashboard", text="Go to dashboard", icon="URL")

    layout.separator(factor=0.5)
    hint = layout.row()
    hint.scale_y = 0.8
    hint.label(text="  Click  Close  to dismiss this window.", icon="INFO")


# ──────────────────────────────────────────────────────────────────────────────
# Submit operator — Step 1: Validation popup
# Closes on outside click (nothing is running yet — that's fine).
# ──────────────────────────────────────────────────────────────────────────────

class RF_OT_Submit(Operator):
    bl_idname      = "rf.submit"
    bl_label       = "Submit"
    bl_description = "Package and upload the scene, then submit the render job to Renderfarm."

    def invoke(self, context, event):
        token      = _get_token()
        blend_path = bpy.context.blend_data.filepath

        _sub["tab"]         = "VALIDATION"
        _sub["is_dirty"]    = bpy.context.blend_data.is_dirty
        _sub["validation"]  = []
        _sub["prog_jobs"]   = 0.0
        _sub["prog_md5"]    = 0.0
        _sub["prog_upload"] = 0.0
        _sub["files"]       = []
        _sub["job_number"]  = ""
        _sub["job_title"]   = context.scene.rf_job_title
        _sub["error"]       = ""

        if not token:
            _sub["validation"].append(
                ("ERROR", "Not connected — click Connect first."))
        if not blend_path:
            _sub["validation"].append(
                ("ERROR", "Please save your .blend file before submitting."))
        elif _sub["is_dirty"]:
            _sub["validation"].append(
                ("WARN", "The current scene has unsaved modifications."))

        return context.window_manager.invoke_popup(self, width=700)

    def draw(self, context):
        _draw_validation(self.layout)

    def execute(self, context):
        return {"FINISHED"}

    def check(self, context):
        return True


# ──────────────────────────────────────────────────────────────────────────────
# Submit operator — Step 2: Persistent progress/response window
# Uses invoke_props_dialog so it stays open even when the mouse moves away.
# The user must explicitly click  Close  to dismiss it.
# ──────────────────────────────────────────────────────────────────────────────

class RF_OT_SubmitProgress(Operator):
    """Progress & response dialog — stays open until you click Close."""
    bl_idname = "rf.submit_progress"
    bl_label  = "Submission Progress"

    def invoke(self, context, event):
        _start_upload_thread(context)

        # Register a repeating timer so the progress bars update smoothly
        # even when the user is not moving the mouse.
        def _tick():
            _redraw()
            return 0.15 if _sub["tab"] == "PROGRESS" else None  # stop when done

        bpy.app.timers.register(_tick, first_interval=0.15)

        try:
            return context.window_manager.invoke_props_dialog(
                self, width=700, confirm_text="Close")
        except TypeError:
            # Blender < 3.4 — confirm_text not available
            return context.window_manager.invoke_props_dialog(self, width=700)

    def draw(self, context):
        tab = _sub["tab"]
        if tab == "PROGRESS":
            _draw_progress(self.layout)
        else:
            _draw_response(self.layout)

    def execute(self, context):
        return {"FINISHED"}

    def check(self, context):
        # Returning True tells Blender to redraw the dialog on every event
        return True


# ── Dialog action operators ────────────────────────────────────────────────────

class RF_OT_SubmitClose(Operator):
    """Close the validation popup."""
    bl_idname = "rf.submit_close"
    bl_label  = "Close"

    def execute(self, context):
        return {"FINISHED"}


class RF_OT_SaveAndContinue(Operator):
    """Save the .blend file, then open the progress window."""
    bl_idname = "rf.save_and_continue"
    bl_label  = "Save Scene and Continue Submission"

    def execute(self, context):
        bpy.ops.wm.save_mainfile()
        _sub["is_dirty"] = False
        # Give Blender one frame to close the validation popup first
        bpy.app.timers.register(
            lambda: bpy.ops.rf.submit_progress("INVOKE_DEFAULT") and None,
            first_interval=0.05,
        )
        return {"FINISHED"}


class RF_OT_ContinueSubmit(Operator):
    """Open the progress window (skip the unsaved-changes warning)."""
    bl_idname = "rf.continue_submit"
    bl_label  = "Continue Submission"

    def execute(self, context):
        bpy.app.timers.register(
            lambda: bpy.ops.rf.submit_progress("INVOKE_DEFAULT") and None,
            first_interval=0.05,
        )
        return {"FINISHED"}


class RF_OT_OpenDashboard(Operator):
    """Open the Renderfarm dashboard in a browser."""
    bl_idname = "rf.open_dashboard"
    bl_label  = "Go to dashboard"

    def execute(self, context):
        webbrowser.open(f"{WEB_BASE}/dashboard")
        return {"FINISHED"}


class RF_OT_AddEnvVar(Operator):
    bl_idname = "rf.add_env_var";    bl_label = "Add Extra Environment Variable"
    def execute(self, context):
        context.scene.rf_env_vars.variables.add(); return {"FINISHED"}

class RF_OT_RemoveEnvVar(Operator):
    bl_idname = "rf.remove_env_var"; bl_label = "Remove Variable"
    index: bpy.props.IntProperty()
    def execute(self, context):
        context.scene.rf_env_vars.variables.remove(self.index); return {"FINISHED"}

class RF_OT_AddFileAsset(Operator):
    bl_idname = "rf.add_file_asset"; bl_label = "Add Extra File Asset"
    filepath: StringProperty(subtype="FILE_PATH")
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self); return {"RUNNING_MODAL"}
    def execute(self, context):
        if self.filepath:
            context.scene.rf_extra_files.add().file_path = self.filepath
        return {"FINISHED"}

class RF_OT_RemoveFileAsset(Operator):
    bl_idname = "rf.remove_file_asset"; bl_label = "Remove"
    index: bpy.props.IntProperty()
    def execute(self, context):
        context.scene.rf_extra_files.remove(self.index); return {"FINISHED"}

class RF_OT_AddDirAsset(Operator):
    bl_idname = "rf.add_dir_asset"; bl_label = "Add Extra Directory Asset"
    filepath: StringProperty(subtype="DIR_PATH")
    def invoke(self, context, event):
        self.filepath = ""; context.window_manager.fileselect_add(self); return {"RUNNING_MODAL"}
    def execute(self, context):
        if self.filepath:
            context.scene.rf_extra_dirs.add().dir_path = self.filepath
        return {"FINISHED"}

class RF_OT_RemoveDirAsset(Operator):
    bl_idname = "rf.remove_dir_asset"; bl_label = "Remove"
    index: bpy.props.IntProperty()
    def execute(self, context):
        context.scene.rf_extra_dirs.remove(self.index); return {"FINISHED"}

# ──────────────────────────────────────────────────────────────────────────────
# Panels
# ──────────────────────────────────────────────────────────────────────────────
class _Base(Panel):
    bl_space_type  = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context     = "render"
    def draw(self, context): pass

class RF_PT_Root(_Base):
    bl_label  = "Renderfarm Render Submitter"
    bl_idname = "RF_PT_root"

class RF_PT_Job(_Base):
    bl_label     = "Renderfarm Job"
    bl_idname    = "RF_PT_job"
    bl_parent_id = "RF_PT_root"

    def draw(self, context):
        layout = self.layout
        scene  = context.scene
        email  = _get_email()

        # Connection status bar
        box = layout.box()
        row = box.row()
        if email:
            row.label(text=email, icon="CHECKMARK")
            row.operator("rf.disconnect", text="Disconnect", icon="PANEL_CLOSE")
        else:
            row.label(text="Not connected", icon="UNLINKED")

        layout.operator("rf.connect",        text="Connect",        icon="LINKED")
        layout.operator("rf.preview_script", text="Preview Script", icon="TEXT")
        layout.operator("rf.submit",         text="Submit",         icon="RENDER_STILL")

        if scene.rf_status_msg:
            row  = layout.row()
            icon = ("CHECKMARK" if scene.rf_status_type == "OK"
                    else "ERROR" if scene.rf_status_type == "ERROR" else "INFO")
            row.label(text=scene.rf_status_msg, icon=icon)

class RF_PT_Configuration(_Base):
    bl_label = "Configuration"; bl_idname = "RF_PT_configuration"; bl_parent_id = "RF_PT_root"

class RF_PT_General(_Base):
    bl_label = "General"; bl_idname = "RF_PT_general"; bl_parent_id = "RF_PT_configuration"

    def draw(self, context):
        layout = self.layout; scene = context.scene
        layout.label(text="Job Title:");      layout.prop(scene, "rf_job_title",        text="")
        layout.label(text="Project:");        layout.prop(scene, "rf_project",           text="")
        layout.label(text="Instance Type:");  layout.prop(scene, "rf_instance_type",     text="")
        layout.label(text="Machine Type:");   layout.prop(scene, "rf_machine_type",      text="")
        layout.prop(scene, "rf_preemptible", text="Preemptible")
        layout.label(text="Preemptible Retries:"); layout.prop(scene, "rf_preemptible_retries", text="")
        layout.label(text="Blender Version:"); layout.prop(scene, "rf_blender_version",  text="")
        layout.label(text="Render Software:"); layout.prop(scene, "rf_render_software",  text="")

class RF_PT_RenderSettings(_Base):
    bl_label = "Render Settings"; bl_idname = "RF_PT_render_settings"; bl_parent_id = "RF_PT_configuration"

    def draw(self, context):
        layout = self.layout; scene = context.scene
        layout.row(align=True).prop(scene, "rf_resolution_x",   text="Resolution X")
        layout.row(align=True).prop(scene, "rf_resolution_y",   text="Resolution Y")
        layout.row(align=True).prop(scene, "rf_resolution_pct", text="Resolution %")
        layout.label(text="Camera:"); layout.prop(scene, "rf_camera_override", text="")
        layout.row(align=True).prop(scene, "rf_samples", text="Samples")

class RF_PT_Frames(_Base):
    bl_label = "Frames"; bl_idname = "RF_PT_frames"; bl_parent_id = "RF_PT_configuration"

    def draw(self, context):
        layout = self.layout; scene = context.scene
        layout.row(align=True).prop(scene, "rf_chunk_size", text="Chunk Size")
        layout.prop(scene, "rf_use_custom_range", text="Use Custom Range")
        if scene.rf_use_custom_range:
            layout.row(align=True).prop(scene, "rf_frame_range", text="Custom Range")
        layout.prop(scene, "rf_use_scout_frames", text="Use Scout Frames")
        layout.row(align=True).prop(scene, "rf_scout_frames", text="Scout Frames")

class RF_PT_FrameInfo(_Base):
    bl_label = "Frame Info"; bl_idname = "RF_PT_frame_info"
    bl_parent_id = "RF_PT_configuration"; bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout; scene = context.scene
        for prop, label in [("rf_frame_spec","Frame Spec"),("rf_frame_count","Frame Count"),("rf_task_count","Task Count")]:
            row = layout.row(align=True); row.active = False; row.prop(scene, prop, text=label)

class RF_PT_Addons(_Base):
    bl_label = "Add-ons"; bl_idname = "RF_PT_addons"; bl_parent_id = "RF_PT_root"

    def draw(self, context):
        layout = self.layout; scene = context.scene
        if scene.rf_addon_props:
            for addon in scene.rf_addon_props:
                row = layout.row()
                row.prop(addon, "enabled", text=addon.name)
                row.prop(addon, "menu_option", text="")
        else:
            layout.label(text="Click Connect to load compatible add-ons.", icon="INFO")

class RF_PT_Advanced(_Base):
    bl_label = "Advanced"; bl_idname = "RF_PT_advanced"; bl_parent_id = "RF_PT_root"

    def draw(self, context):
        self.layout.prop(context.scene, "rf_output_folder", text="Output Folder")

class RF_PT_ExtraFiles(_Base):
    bl_label = "Extra File Assets"; bl_idname = "RF_PT_extra_files"; bl_parent_id = "RF_PT_advanced"

    def draw(self, context):
        layout = self.layout; scene = context.scene
        layout.operator("rf.add_file_asset", text="Add Extra File Asset")
        for i, item in enumerate(scene.rf_extra_files):
            row = layout.row(align=True); row.prop(item, "file_path", text="")
            row.operator("rf.remove_file_asset", text="", icon="X").index = i

class RF_PT_ExtraDirs(_Base):
    bl_label = "Extra Directory Assets"; bl_idname = "RF_PT_extra_dirs"; bl_parent_id = "RF_PT_advanced"

    def draw(self, context):
        layout = self.layout; scene = context.scene
        layout.operator("rf.add_dir_asset", text="Add Extra Directory Asset")
        for i, item in enumerate(scene.rf_extra_dirs):
            row = layout.row(align=True); row.prop(item, "dir_path", text="")
            row.operator("rf.remove_dir_asset", text="", icon="X").index = i

class RF_PT_ExtraEnv(_Base):
    bl_label = "Extra Environment"; bl_idname = "RF_PT_extra_env"; bl_parent_id = "RF_PT_advanced"

    def draw(self, context):
        layout = self.layout; scene = context.scene
        layout.operator("rf.add_env_var", text="Add Extra Environment Variable")
        for i, var in enumerate(scene.rf_env_vars.variables):
            row = layout.row()
            row.prop(var, "variable_name",  text="Variable")
            row.prop(var, "variable_value", text="Value")
            row.operator("rf.remove_env_var", text="", icon="X").index = i

class RF_PT_AdditionalOptions(_Base):
    bl_label = "Additional Rendering Options"; bl_idname = "RF_PT_additional_options"; bl_parent_id = "RF_PT_advanced"

    def draw(self, context):
        layout = self.layout; scene = context.scene
        layout.prop(scene, "rf_disable_audio",           text="Disable Audio")
        layout.prop(scene, "rf_update_camera_per_frame", text="Update active camera every frame")
        layout.prop(scene, "rf_render_all_view_layers",  text="Render all active view layers")

# ──────────────────────────────────────────────────────────────────────────────
# Registration
# ──────────────────────────────────────────────────────────────────────────────
CLASSES = [
    RFExtraFileAsset, RFExtraDirAsset, RFEnvVar, RFEnvVarList, RFAddonProp,
    RFPreferences,
    RF_OT_Connect, RF_OT_Disconnect, RF_OT_PreviewScript, RF_OT_Submit,
    RF_OT_SubmitProgress,
    RF_OT_SubmitClose, RF_OT_SaveAndContinue, RF_OT_ContinueSubmit, RF_OT_OpenDashboard,
    RF_OT_AddEnvVar, RF_OT_RemoveEnvVar,
    RF_OT_AddFileAsset, RF_OT_RemoveFileAsset,
    RF_OT_AddDirAsset,  RF_OT_RemoveDirAsset,
    RF_PT_Root, RF_PT_Job, RF_PT_Configuration,
    RF_PT_General, RF_PT_RenderSettings, RF_PT_Frames, RF_PT_FrameInfo,
    RF_PT_Addons, RF_PT_Advanced,
    RF_PT_ExtraFiles, RF_PT_ExtraDirs, RF_PT_ExtraEnv, RF_PT_AdditionalOptions,
]

def register():
    for cls in CLASSES:
        register_class(cls)

    S = bpy.types.Scene
    S.rf_job_title             = bpy.props.StringProperty(name="Job Title", default="Blender Linux Render")
    S.rf_project               = bpy.props.EnumProperty(name="Project", items=[("none","— click Connect —","")])
    S.rf_instance_type         = bpy.props.EnumProperty(name="Instance Type", items=[("GPU","GPU",""),("CPU","CPU","")], update=_update_instance_type)
    S.rf_machine_type          = bpy.props.EnumProperty(name="Machine Type", items=INSTANCE_TYPES["GPU"])
    S.rf_preemptible           = bpy.props.BoolProperty(name="Preemptible", default=True)
    S.rf_preemptible_retries   = bpy.props.IntProperty(name="Preempted Retries", default=1, min=1, max=100)
    S.rf_blender_version       = bpy.props.EnumProperty(name="Blender Version", items=BLENDER_VERSIONS)
    S.rf_render_software       = bpy.props.EnumProperty(name="Render Software", items=[("Cycles","Cycles",""),("Eevee","Eevee","")])
    S.rf_resolution_x          = bpy.props.IntProperty(name="Resolution X", min=1, max=16384)
    S.rf_resolution_y          = bpy.props.IntProperty(name="Resolution Y", min=1, max=16384)
    S.rf_resolution_pct        = bpy.props.IntProperty(name="Resolution %", min=1, max=1000)
    S.rf_camera_override       = bpy.props.EnumProperty(name="Camera", items=[("none","None","")])
    S.rf_samples               = bpy.props.IntProperty(name="Samples", min=1, max=10000)
    S.rf_chunk_size            = bpy.props.IntProperty(name="Chunk Size", default=1, min=1, max=800, update=_on_chunk_updated)
    S.rf_use_custom_range      = bpy.props.BoolProperty(name="Use Custom Range", default=True)
    S.rf_frame_range           = bpy.props.StringProperty(name="Custom Range", default="1-100", update=_on_range_updated)
    S.rf_use_scout_frames      = bpy.props.BoolProperty(name="Use Scout Frames", default=True)
    S.rf_scout_frames          = bpy.props.StringProperty(name="Scout Frames", default="fml:3")
    S.rf_frame_spec            = bpy.props.StringProperty(name="Frame Spec",  default="")
    S.rf_frame_count           = bpy.props.StringProperty(name="Frame Count", default="")
    S.rf_task_count            = bpy.props.StringProperty(name="Task Count",  default="")
    S.rf_output_folder         = bpy.props.StringProperty(name="Output Folder", default="", subtype="DIR_PATH")
    S.rf_disable_audio         = bpy.props.BoolProperty(name="Disable Audio", default=True)
    S.rf_update_camera_per_frame = bpy.props.BoolProperty(name="Update active camera every frame", default=False)
    S.rf_render_all_view_layers  = bpy.props.BoolProperty(name="Render all active view layers", default=False)
    S.rf_status_msg            = bpy.props.StringProperty(default="")
    S.rf_status_type           = bpy.props.StringProperty(default="INFO")
    S.rf_extra_files           = CollectionProperty(type=RFExtraFileAsset)
    S.rf_extra_dirs            = CollectionProperty(type=RFExtraDirAsset)
    S.rf_env_vars              = bpy.props.PointerProperty(type=RFEnvVarList)
    S.rf_addon_props           = CollectionProperty(type=RFAddonProp)

    # Auto-restore saved session
    token, email = _load_token()
    if token and email:
        def _restore():
            try:
                prefs = bpy.context.preferences.addons[__name__].preferences
                prefs.access_token = token
                prefs.user_email   = email
            except Exception:
                pass
        bpy.app.timers.register(_restore, first_interval=0.5)


def unregister():
    _stop_auth_server()
    props = [
        "rf_job_title","rf_project","rf_instance_type","rf_machine_type",
        "rf_preemptible","rf_preemptible_retries","rf_blender_version","rf_render_software",
        "rf_resolution_x","rf_resolution_y","rf_resolution_pct","rf_camera_override","rf_samples",
        "rf_chunk_size","rf_use_custom_range","rf_frame_range","rf_use_scout_frames","rf_scout_frames",
        "rf_frame_spec","rf_frame_count","rf_task_count","rf_output_folder","rf_disable_audio",
        "rf_update_camera_per_frame","rf_render_all_view_layers","rf_status_msg","rf_status_type",
        "rf_extra_files","rf_extra_dirs","rf_env_vars","rf_addon_props",
    ]
    for p in props:
        if hasattr(bpy.types.Scene, p): delattr(bpy.types.Scene, p)
    for cls in reversed(CLASSES):
        unregister_class(cls)


if __name__ == "__main__":
    register()
